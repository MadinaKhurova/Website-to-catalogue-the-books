<?php
session_start();
date_default_timezone_set('Europe/Berlin'); // Adjust this to your local time zone

include('includes/header.php');
include('includes/functions.php'); // Ensure the correct path to functions.php

// Fetch books from JSON
$books = json_decode(file_get_contents('data/books.json'), true);
$users = json_decode(file_get_contents('data/users.json'), true);

$bookId = $_GET['id'] ?? '';
$username = $_SESSION['username'] ?? '';

$book = current(array_filter($books, function($b) use ($bookId) {
    return $b['id'] === $bookId;
}));

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($username)) {
    if (isset($_POST['review'], $_POST['rating'])) {
        $review = trim($_POST['review']);
        $rating = (int)$_POST['rating'];
        
        if (!empty($review) && $rating >= 1 && $rating <= 5) {
            if (!isset($book['reviews'])) {
                $book['reviews'] = [];
            }
            if (!isset($book['ratings'])) {
                $book['ratings'] = [];
            }
            $book['reviews'][] = ["user" => $username, "review" => $review, "rating" => $rating];
            $book['ratings'][] = $rating;

            foreach ($books as &$b) {
                if ($b['id'] === $bookId) {
                    $b = $book;
                    break;
                }
            }
            file_put_contents('data/books.json', json_encode($books, JSON_PRETTY_PRINT));
        }
    }

    if (isset($_POST['mark_as_read'])) {
        $currentTime = date('c');
        $found = false;
        foreach ($users as &$user) {
            if ($user['username'] === $username) {
                $user['read_books'][] = ['id' => $bookId, 'time_read' => $currentTime];
                file_put_contents('data/users.json', json_encode($users, JSON_PRETTY_PRINT));
                break;
            }
        }
    }
}
?>

<!-- Your HTML and PHP continue from here -->


<div id="content">
    <?php if ($book): ?>
        <h2><?php echo htmlspecialchars($book['title']); ?></h2>
        <div class="book-image">
            <img src="<?php echo filter_var($book['image'], FILTER_VALIDATE_URL) ? $book['image'] : 'assets/' . htmlspecialchars($book['image']); ?>" alt="<?php echo 'Cover image of ' . htmlspecialchars($book['title']); ?>" style="max-width: 100%; height: auto;">
        </div>
        <p><strong>Author:</strong> <?php echo htmlspecialchars($book['author']); ?></p>
        <p><strong>Description:</strong> <?php echo htmlspecialchars($book['description']); ?></p>
        <p><strong>Year:</strong> <?php echo htmlspecialchars($book['year']); ?></p>
        <p><strong>Planet:</strong> <?php echo htmlspecialchars($book['planet']); ?></p>
        <p><strong>Average Rating:</strong> <?php echo (isset($book['ratings']) && !empty($book['ratings'])) ? calculate_average_rating($book['ratings']) : 'No ratings'; ?></p>
        <h3>Reviews</h3>
        <ul>
            <?php if (isset($book['reviews']) && is_array($book['reviews'])): ?>
                <?php foreach ($book['reviews'] as $review): ?>
                    <li><strong><?php echo htmlspecialchars($review['user']); ?>:</strong> <?php echo htmlspecialchars($review['review']); ?> - Rating: <?php echo isset($review['rating']) ? htmlspecialchars($review['rating']) : 'No rating provided'; ?></li>
                <?php endforeach; ?>
            <?php else: ?>
                <li>No reviews yet.</li>
            <?php endif; ?>
        </ul>

        <?php if (isset($username) && !empty($username)): ?>
            <form action="details.php?id=<?php echo $bookId; ?>" method="post">
                <label for="rating">Rating:</label>
                <select name="rating" id="rating" required>
                    <option value="">Select rating</option>
                    <option value="1">1</option>
                    <option value="2">2</option>
                    <option value="3">3</option>
                    <option value="4">4</option>
                    <option value="5">5</option>
                </select><br>
                <label for="review">Review:</label><br>
                <textarea name="review" id="review" required></textarea><br>
                <input type="submit" value="Submit Review">
            </form>
            <form action="details.php?id=<?php echo $bookId; ?>" method="post" style="margin-top: 10px;">
                <input type="hidden" name="mark_as_read" value="1">
                <input type="submit" value="Mark as Read">
            </form>
        <?php else: ?>
            <p><a href="login.php">Login</a> to write a review or mark this book as read.</p>
        <?php endif; ?>
    <?php else: ?>
        <p>Book not found.</p>
    <?php endif; ?>
</div>
<?php
$readByUsers = [];
foreach ($users as $user) {
    if (isset($user['read_books'])) {
        foreach ($user['read_books'] as $readBook) {
            if ($readBook['id'] == $bookId) {
                $readByUsers[] = ['username' => $user['username'], 'time_read' => $readBook['time_read']];
            }
        }
    }
}
?>
<div>
    <h3>Read by:</h3>
    <ul>
        <?php foreach ($readByUsers as $user): ?>
            <li><?php echo htmlspecialchars($user['username']) . " on " . date("F j, Y, g:i a", strtotime($user['time_read'])); ?></li>
        <?php endforeach; ?>
    </ul>
</div>

<?php include('includes/footer.php'); ?>
