<?php
// Define a function to calculate the average rating
function calculate_average_rating($ratings) {
    // Check if ratings is an array and it's not empty to avoid errors
    if (is_array($ratings) && count($ratings) > 0) {
        return round(array_sum($ratings) / count($ratings), 1);
    }
    return 'No ratings'; // Return a default message if no ratings are available
}
