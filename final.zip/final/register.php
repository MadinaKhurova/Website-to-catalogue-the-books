<?php
session_start();
include('includes/header.php');
include('includes/functions.php'); // Ensure the correct path to functions.php

// Fetch users from JSON
$users = json_decode(file_get_contents('data/users.json'), true);

$errors = [];
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    $confirmPassword = trim($_POST['confirm_password']);
    
    // Check if username or email already exists
    foreach ($users as $user) {
        if ($user['username'] === $username) {
            $errors[] = "Username already taken.";
        }
        if ($user['email'] === $email) {
            $errors[] = "Email already in use.";
        }
    }
    
    // Check if passwords match
    if ($password !== $confirmPassword) {
        $errors[] = "Passwords do not match.";
    }

    // If no errors, register the user
    if (empty($errors)) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $newUser = [
            "username" => $username,
            "email" => $email,
            "password" => $hashedPassword,
            "last_login" => null,
            "is_admin" => false,
            "read_books" => []
        ];
        $users[] = $newUser;
        file_put_contents('data/users.json', json_encode($users, JSON_PRETTY_PRINT));
        
        $_SESSION['username'] = $username;
        header('Location: index.php');
        exit;
    }
}
?>

<div id="content">
    <h2>Register</h2>
    <?php if (!empty($errors)): ?>
        <div class="errors">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="register.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>
        
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required><br>
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        
        <label for="confirm_password">Confirm Password:</label>
        <input type="password" id="confirm_password" name="confirm_password" required><br>
        
        <input type="submit" value="Register">
    </form>
</div>

<?php include('includes/footer.php'); ?>
