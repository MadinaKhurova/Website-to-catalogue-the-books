<?php
session_start();
include('includes/header.php');
include('includes/functions.php'); // Ensure the correct path to functions.php

$users = json_decode(file_get_contents('data/users.json'), true);
$errors = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = trim($_POST['password']);

    foreach ($users as &$user) {
        if ($user['username'] === $username && password_verify($password, $user['password'])) {
            $_SESSION['username'] = $username;
            $_SESSION['is_admin'] = $user['is_admin']; // Assuming you have an 'is_admin' flag in your user data
            
            // Update last login
            $user['last_login'] = date('Y-m-d H:i:s');
            file_put_contents('data/users.json', json_encode($users, JSON_PRETTY_PRINT));

            if ($_SESSION['is_admin']) {
                header('Location: admin.php'); // Redirect to admin page if user is an admin
            } else {
                header('Location: index.php'); // Redirect to index page for regular users
            }
            exit;
        }
    }

    $errors[] = "Invalid username or password.";
}
?>

<div id="content">
    <h2>Login</h2>
    <?php if (!empty($errors)): ?>
        <div class="errors">
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li><?php echo htmlspecialchars($error); ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    <?php endif; ?>
    <form action="login.php" method="post">
        <label for="username">Username:</label>
        <input type="text" id="username" name="username" required><br>
        
        <label for="password">Password:</label>
        <input type="password" id="password" name="password" required><br>
        
        <input type="submit" value="Login">
    </form>
</div>

<?php include('includes/footer.php'); ?>
