<?php
session_start();
include('includes/header.php');
include('includes/functions.php'); // Include the function for calculating average ratings

$books = json_decode(file_get_contents('data/books.json'), true);

function sortBooksByRating(&$books) {
    foreach ($books as &$book) {
        $book['average_rating'] = calculate_average_rating($book['ratings'] ?? []);
    }
    usort($books, function($a, $b) {
        return $b['average_rating'] <=> $a['average_rating'];
    });
}

sortBooksByRating($books);

$selectedGenre = $_GET['genre'] ?? '';
$filteredBooks = $selectedGenre ? array_filter($books, function($book) use ($selectedGenre) {
    return isset($book['genre']) && $book['genre'] === $selectedGenre;
}) : $books;

$genres = [];
foreach ($books as $book) {
    if (isset($book['genre'])) {
        $genres[] = $book['genre'];
    }
}
$genres = array_unique($genres);
?>

<div id="content">
    <form method="get" action="index.php">
        <label for="genre">Filter by Genre:</label>
        <select name="genre" id="genre" onchange="this.form.submit()">
            <option value="">All</option>
            <?php foreach ($genres as $genre): ?>
                <option value="<?php echo htmlspecialchars($genre); ?>" <?php if ($selectedGenre === $genre) echo 'selected'; ?>>
                    <?php echo htmlspecialchars($genre); ?>
                </option>
            <?php endforeach; ?>
        </select>
    </form>

    <div id="card-list">
        <?php foreach ($filteredBooks as $book): ?>
            <div class="book-card">
                <div class="image">
                    <img src="<?php echo filter_var($book['image'], FILTER_VALIDATE_URL) ? $book['image'] : 'assets/' . htmlspecialchars($book['image']); ?>" alt="<?php echo 'Cover image of ' . htmlspecialchars($book['title']); ?>" style="width: 200px; height: 300px; object-fit: cover;">
                </div>
                <div class="details">
                    <h2><a href="details.php?id=<?php echo $book['id']; ?>"><?php echo htmlspecialchars($book['title']); ?></a></h2>
                    <p>Author: <?php echo htmlspecialchars($book['author']); ?></p>
                    <p>Average Rating: <?php 
                        echo is_numeric($book['average_rating']) ? number_format($book['average_rating'], 1) : 'No ratings'; 
                    ?></p>
                    <p>Genre: <?php echo htmlspecialchars($book['genre'] ?? 'No genre specified'); ?></p>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<?php include('includes/footer.php'); ?>
