<?php
session_start();
include('includes/header.php');

if ($_SESSION['username'] !== 'admin') {
    header('Location: index.php');
    exit;
}

// Load books
$books = json_decode(file_get_contents('data/books.json'), true);

$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate form inputs
    $title = trim($_POST['title']);
    $author = trim($_POST['author']);
    $description = trim($_POST['description']);
    $year = trim($_POST['year']);
    $image = trim($_POST['image']);
    $planet = trim($_POST['planet']);
    $genre = trim($_POST['genre']); // Add genre to the form processing

    if (empty($title) || empty($author) || empty($description) || empty($year) || empty($image) || empty($planet) || empty($genre)) {
        $error = "All fields are required.";
    } else if (!is_numeric($year) || $year < 0) {
        $error = "Invalid year.";
    } else if (!preg_match('/^P[a-zA-Z0-9]{2}-[0-9]{3,4}$/', $planet)) {
        $error = "Invalid planet format.";
    } else {
        // Add new book
        $newBook = [
            "id" => "book" . count($books),
            "title" => $title,
            "author" => $author,
            "description" => $description,
            "year" => (int)$year,
            "image" => $image,
            "planet" => $planet,
            "genre" => $genre // Add genre to book details
        ];
        $books[] = $newBook;
        file_put_contents('data/books.json', json_encode($books));
        $success = "Book added successfully!";
    }
}

if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $books = array_filter($books, function($b) use ($id) {
        return $b['id'] !== $id;
    });
    file_put_contents('data/books.json', json_encode($books));
    header('Location: admin.php');
    exit;
}
?>

<h2>Admin Panel</h2>
<?php if ($error): ?>
    <p style="color: red;"><?php echo $error; ?></p>
<?php endif; ?>
<?php if ($success): ?>
    <p style="color: green;"><?php echo $success; ?></p>
<?php endif; ?>

<h3>Add New Book</h3>
<form action="admin.php" method="post">
    <label>Title: <input type="text" name="title" value="<?php echo htmlspecialchars($title ?? ''); ?>" required></label><br>
    <label>Author: <input type="text" name="author" value="<?php echo htmlspecialchars($author ?? ''); ?>" required></label><br>
    <label>Description: <textarea name="description" required><?php echo htmlspecialchars($description ?? ''); ?></textarea></label><br>
    <label>Year: <input type="number" name="year" value="<?php echo htmlspecialchars($year ?? ''); ?>" required></label><br>
    <label>Image Filename: <input type="text" name="image" value="<?php echo htmlspecialchars($image ?? ''); ?>" required></label><br>
    <label>Planet: <input type="text" name="planet" value="<?php echo htmlspecialchars($planet ?? ''); ?>" required pattern="P[a-zA-Z0-9]{2}-[0-9]{3,4}"></label><br>
    <label>Genre: <select name="genre" required>
        <option value="">Select Genre</option>
        <option value="Manga">Manga</option>
        <option value="Romance">Romance</option>
        <option value="Adventure">Adventure</option>
    </select></label><br>
    <input type="submit" value="Add Book">
</form>

<h3>Current Books</h3>
<div id="card-list">
    <?php foreach ($books as $book): ?>
        <div class="book-card">
            <div class="image">
                <?php
                // Check if the image path is an external URL or a local file
                $imageSrc = (strpos($book['image'], 'http://') === 0 || strpos($book['image'], 'https://') === 0) ? $book['image'] : "assets/" . $book['image'];
                ?>
                <img src="<?php echo htmlspecialchars($imageSrc); ?>" alt="<?php echo htmlspecialchars($book['title']); ?>" style="width: 200px; height: 300px; object-fit: cover;">
            </div>
            <div class="details">
                <h2><?php echo htmlspecialchars($book['title']); ?></h2>
                <p>Author: <?php echo htmlspecialchars($book['author']); ?></p>
                <p>Year: <?php echo htmlspecialchars($book['year']); ?></p>
                <p>Planet: <?php echo htmlspecialchars($book['planet']); ?></p>
                <a href="admin.php?delete=<?php echo htmlspecialchars($book['id']); ?>">Delete</a>
            </div>
        </div>
    <?php endforeach; ?>
</div>

<?php include('includes/footer.php'); ?>
