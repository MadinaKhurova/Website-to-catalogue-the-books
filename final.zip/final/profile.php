<?php
session_start();
include('includes/header.php');
include('includes/functions.php'); // Ensure this includes necessary functions like calculate_average_rating

if (!isset($_SESSION['username'])) {
    header('Location: login.php');
    exit;
}

$books = json_decode(file_get_contents('data/books.json'), true);
$users = json_decode(file_get_contents('data/users.json'), true);
$username = $_SESSION['username'];

$user = current(array_filter($users, function($u) use ($username) {
    return $u['username'] === $username;
}));

$readBooks = [];
$userReviews = [];

// Ensure that user's read_books are set and is an array
if (isset($user['read_books']) && is_array($user['read_books'])) {
    foreach ($user['read_books'] as $readBook) {
        foreach ($books as $book) {
            if ($book['id'] === $readBook['id']) {
                $book['time_read'] = $readBook['time_read'];
                $readBooks[] = $book;
                break;
            }
        }
    }
}

// Ensure that there are reviews and they are in array format
foreach ($books as $book) {
    if (isset($book['reviews']) && is_array($book['reviews'])) {
        foreach ($book['reviews'] as $review) {
            if ($review['user'] === $username) {
                $ratingText = isset($review['rating']) ? $review['rating'] : 'No rating provided'; // Safe check for rating
                $userReviews[] = [
                    'book_id' => $book['id'],
                    'book_title' => $book['title'],
                    'review' => $review['review'],
                    'rating' => $ratingText  // Use safe rating
                ];
            }
        }
    }
}

// Sort the read books by time read, most recent first
usort($readBooks, function ($a, $b) {
    return strtotime($b['time_read']) - strtotime($a['time_read']);
});
?>

<div id="content">
    <h2><?php echo htmlspecialchars($username); ?>'s Profile</h2>
    
    <h3>User Details</h3>
    <p><strong>Name:</strong> <?php echo htmlspecialchars($user['username']); ?></p>
    <p><strong>Email:</strong> <?php echo htmlspecialchars($user['email']); ?></p>
    <p><strong>Last Login:</strong> <?php echo htmlspecialchars($user['last_login'] ?? 'Never'); ?></p>
    
    <h3>Books Read</h3>
    <ul>
        <?php foreach ($readBooks as $book): ?>
            <li>
                <a href="details.php?id=<?php echo $book['id']; ?>">
                    <?php echo htmlspecialchars($book['title']); ?>
                </a> - Read on <?php echo date("F j, Y, g:i a", strtotime($book['time_read'])); ?>
            </li>
        <?php endforeach; ?>
    </ul>

    <h3>My Reviews</h3>
    <ul>
        <?php foreach ($userReviews as $review): ?>
            <li>
                <strong><?php echo htmlspecialchars($review['book_title']); ?>:</strong> 
                <?php echo htmlspecialchars($review['review']); ?>
                - Rating: <?php echo htmlspecialchars($review['rating']); ?>
                <a href="details.php?id=<?php echo $review['book_id']; ?>">(View Book)</a>
            </li>
        <?php endforeach; ?>
    </ul>
</div>

<?php include('includes/footer.php'); ?>
